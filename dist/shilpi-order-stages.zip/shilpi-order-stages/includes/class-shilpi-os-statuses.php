<?php
/**
 * Custom order statuses, list badges, filter, bulk actions and auto-move.
 *
 * @package Shilpi_Order_Stages
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers stages 1 to 8 as WooCommerce order statuses.
 */
class Shilpi_OS_Statuses {

	const AUTO_MOVE_HOOK = 'shilpi_os_auto_move';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_statuses' ) );
		add_filter( 'wc_order_statuses', array( $this, 'add_to_order_statuses' ) );
		add_filter( 'woocommerce_order_is_paid_statuses', array( $this, 'add_custom_keys' ) );
		add_filter( 'woocommerce_reports_order_statuses', array( $this, 'add_to_reports' ) );
		add_filter( 'woocommerce_analytics_actionable_statuses', array( $this, 'add_custom_keys' ) );
		add_filter( 'woocommerce_order_is_download_permitted', array( $this, 'download_permitted' ), 10, 2 );

		// Order list: badge colours, stage filter, bulk actions (legacy and HPOS screens).
		add_action( 'admin_head', array( $this, 'badge_css' ) );
		add_action( 'restrict_manage_posts', array( $this, 'legacy_stage_filter' ) );
		add_filter( 'request', array( $this, 'legacy_filter_request' ) );
		add_action( 'woocommerce_order_list_table_restrict_manage_orders', array( $this, 'hpos_stage_filter' ) );
		add_filter( 'woocommerce_order_list_table_prepare_items_query_args', array( $this, 'hpos_filter_query' ) );
		add_filter( 'bulk_actions-edit-shop_order', array( $this, 'bulk_actions' ), 20 );
		add_filter( 'bulk_actions-woocommerce_page_wc-orders', array( $this, 'bulk_actions' ), 20 );
		add_filter( 'handle_bulk_actions-edit-shop_order', array( $this, 'handle_quiet_bulk' ), 10, 3 );
		add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', array( $this, 'handle_quiet_bulk' ), 10, 3 );

		// Auto-move new Processing orders to "Supplier unpaid".
		add_action( 'woocommerce_order_status_changed', array( $this, 'auto_move' ), 20, 4 );
		add_action( self::AUTO_MOVE_HOOK, array( $this, 'run_auto_move' ) );
	}

	/**
	 * Register post statuses (used by both storage engines).
	 */
	public function register_statuses() {
		foreach ( Shilpi_OS_Stages::get_custom_stages() as $key => $stage ) {
			register_post_status(
				'wc-' . $key,
				array(
					'label'                     => $stage['label'],
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( '%s order', '%s orders', 'shilpi-order-stages' ),
				)
			);
			// Keep the stage name in the count label.
			global $wp_post_statuses;
			if ( isset( $wp_post_statuses[ 'wc-' . $key ] ) ) {
				$wp_post_statuses[ 'wc-' . $key ]->label_count = array(
					0          => $stage['label'] . ' <span class="count">(%s)</span>',
					1          => $stage['label'] . ' <span class="count">(%s)</span>',
					'singular' => $stage['label'] . ' <span class="count">(%s)</span>',
					'plural'   => $stage['label'] . ' <span class="count">(%s)</span>',
					'context'  => null,
					'domain'   => null,
				);
			}
		}
	}

	/**
	 * Insert our statuses right after "Processing" and rename Completed in context.
	 *
	 * @param array $statuses Statuses.
	 * @return array
	 */
	public function add_to_order_statuses( $statuses ) {
		// Customers see the friendly name (for example "Order confirmed" instead of "Supplier unpaid"),
		// but only while a customer facing view is rendered. Order notes written by cron, Action
		// Scheduler, REST, WP-CLI or gateways always use the admin name.
		$field  = Shilpi_OS_Stages::in_customer_view() ? 'short' : 'label';
		$custom = array();
		foreach ( Shilpi_OS_Stages::get_custom_stages() as $key => $stage ) {
			$custom[ 'wc-' . $key ] = $stage[ $field ];
		}
		$out = array();
		foreach ( $statuses as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'wc-processing' === $key ) {
				$out += $custom;
			}
		}
		return $out + $custom;
	}

	/**
	 * Add custom stage keys (without "wc-") to a status list.
	 *
	 * @param array $statuses Statuses.
	 * @return array
	 */
	public function add_custom_keys( $statuses ) {
		return array_values( array_unique( array_merge( (array) $statuses, array_keys( Shilpi_OS_Stages::get_custom_stages() ) ) ) );
	}

	/**
	 * Add custom stages to legacy reports.
	 *
	 * @param array|false $statuses Statuses.
	 * @return array|false
	 */
	public function add_to_reports( $statuses ) {
		if ( ! is_array( $statuses ) || ! in_array( 'processing', $statuses, true ) ) {
			return $statuses;
		}
		return $this->add_custom_keys( $statuses );
	}

	/**
	 * Allow downloads for orders in a paid stage.
	 *
	 * @param bool     $permitted Permitted.
	 * @param WC_Order $order     Order.
	 * @return bool
	 */
	public function download_permitted( $permitted, $order ) {
		if ( $order instanceof WC_Order && array_key_exists( $order->get_status(), Shilpi_OS_Stages::get_custom_stages() ) ) {
			return true;
		}
		return $permitted;
	}

	/**
	 * Print badge colours for the order list and edit screens.
	 */
	public function badge_css() {
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, self::order_screen_ids(), true ) ) {
			return;
		}
		$css = '';
		foreach ( Shilpi_OS_Stages::get_custom_stages() as $key => $stage ) {
			$bg   = sanitize_hex_color( $stage['color'] ) ? sanitize_hex_color( $stage['color'] ) : '#e5e5e5';
			$css .= sprintf(
				'.order-status.status-%1$s{background:%2$s;color:%3$s;}',
				sanitize_html_class( $key ),
				$bg,
				self::text_color( $bg )
			);
		}
		echo '<style id="shilpi-os-badges">' . wp_strip_all_tags( $css ) . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from sanitised colours and class names.
	}

	/**
	 * Screen ids of the order list and edit screens (legacy and HPOS) and the dashboard.
	 *
	 * @return array
	 */
	public static function order_screen_ids() {
		return array( 'edit-shop_order', 'shop_order', 'woocommerce_page_wc-orders', 'woocommerce_page_shilpi-os-dashboard' );
	}

	/**
	 * Pick black or white text for a background colour.
	 *
	 * @param string $hex Hex colour.
	 * @return string
	 */
	public static function text_color( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$r = hexdec( substr( $hex, 0, 2 ) );
		$g = hexdec( substr( $hex, 2, 2 ) );
		$b = hexdec( substr( $hex, 4, 2 ) );
		return ( ( $r * 299 + $g * 587 + $b * 114 ) / 1000 ) > 150 ? '#1d2327' : '#ffffff';
	}

	/**
	 * Render the stage dropdown.
	 *
	 * @param string[] $current Selected stages.
	 */
	private function render_stage_select( $current ) {
		$value = implode( ',', $current );
		echo '<select name="shilpi_os_stage" id="shilpi-os-stage-filter">';
		echo '<option value="">' . esc_html__( 'All stages', 'shilpi-order-stages' ) . '</option>';
		if ( count( $current ) > 1 ) {
			$labels = array_map( array( 'Shilpi_OS_Stages', 'label' ), $current );
			printf( '<option value="%1$s" selected="selected">%2$s</option>', esc_attr( $value ), esc_html( implode( ' + ', $labels ) ) );
		}
		foreach ( Shilpi_OS_Stages::get_stages() as $key => $stage ) {
			printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $key ), selected( $value, $key, false ), esc_html( $stage['label'] ) );
		}
		echo '</select>';
	}

	/**
	 * Requested stage filter: one stage or a comma separated list, validated against the stage list.
	 *
	 * @return string[]
	 */
	private function requested_stages() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only list filter.
		$raw = isset( $_GET['shilpi_os_stage'] ) ? sanitize_text_field( wp_unslash( $_GET['shilpi_os_stage'] ) ) : '';
		if ( '' === $raw ) {
			return array();
		}
		$stages = array_filter( array_map( 'sanitize_key', explode( ',', $raw ) ), array( 'Shilpi_OS_Stages', 'is_stage' ) );
		return array_values( array_unique( $stages ) );
	}

	/**
	 * Stage keys with the "wc-" prefix.
	 *
	 * @param string[] $stages Stages.
	 * @return string[]
	 */
	private static function prefixed( $stages ) {
		return array_map(
			function ( $stage ) {
				return 'wc-' . $stage;
			},
			$stages
		);
	}

	/**
	 * Stage filter on the legacy (posts) order list.
	 *
	 * @param string $post_type Post type.
	 */
	public function legacy_stage_filter( $post_type ) {
		if ( 'shop_order' === $post_type ) {
			$this->render_stage_select( $this->requested_stages() );
		}
	}

	/**
	 * Apply the stage filter on the legacy order list.
	 *
	 * @param array $vars Query vars.
	 * @return array
	 */
	public function legacy_filter_request( $vars ) {
		global $typenow;
		if ( is_admin() && 'shop_order' === $typenow ) {
			$stages = $this->requested_stages();
			if ( $stages ) {
				$vars['post_status'] = self::prefixed( $stages );
			}
		}
		return $vars;
	}

	/**
	 * Stage filter on the HPOS order list.
	 *
	 * @param string $order_type Order type.
	 */
	public function hpos_stage_filter( $order_type = 'shop_order' ) {
		if ( 'shop_order' === $order_type ) {
			$this->render_stage_select( $this->requested_stages() );
		}
	}

	/**
	 * Apply the stage filter on the HPOS order list.
	 *
	 * @param array $args Query args.
	 * @return array
	 */
	public function hpos_filter_query( $args ) {
		$stages = $this->requested_stages();
		if ( $stages ) {
			$args['status'] = self::prefixed( $stages );
		}
		return $args;
	}

	/**
	 * Add "Stage: X" and "Stage (no email): X" bulk actions. WooCommerce core handles "mark_{status}"
	 * and already offers "Change status to completed", so Delivered only gets the no email variant.
	 *
	 * @param array $actions Actions.
	 * @return array
	 */
	public function bulk_actions( $actions ) {
		foreach ( Shilpi_OS_Stages::get_custom_stages() as $key => $stage ) {
			/* translators: %s: stage name */
			$actions[ 'mark_' . $key ] = sprintf( __( 'Stage: %s', 'shilpi-order-stages' ), $stage['label'] );
		}
		foreach ( Shilpi_OS_Stages::get_stages() as $key => $stage ) {
			/* translators: %s: stage name */
			$actions[ 'shilpi_os_quiet_' . $key ] = sprintf( __( 'Stage (no email): %s', 'shilpi-order-stages' ), $stage['label'] );
		}
		return $actions;
	}

	/**
	 * Handle "Change stage to X (no email)". Nonces are checked by core before this filter runs.
	 *
	 * @param string $redirect Redirect URL.
	 * @param string $action   Action.
	 * @param array  $ids      Order IDs.
	 * @return string
	 */
	public function handle_quiet_bulk( $redirect, $action, $ids ) {
		if ( 0 !== strpos( $action, 'shilpi_os_quiet_' ) || ! current_user_can( 'edit_shop_orders' ) ) {
			return $redirect;
		}
		$stage = substr( $action, strlen( 'shilpi_os_quiet_' ) );
		if ( ! Shilpi_OS_Stages::is_stage( $stage ) ) {
			return $redirect;
		}
		Shilpi_OS_Stage_Changer::suppress_emails( true );
		$changed = 0;
		foreach ( array_map( 'absint', (array) $ids ) as $id ) {
			$order = wc_get_order( $id );
			if ( $order && $order->get_status() !== $stage ) {
				$order->update_status( $stage, __( 'Stage changed by bulk edit (no email).', 'shilpi-order-stages' ), true );
				++$changed;
			}
		}
		Shilpi_OS_Stage_Changer::suppress_emails( false );
		return add_query_arg(
			array(
				'bulk_action' => 'marked_' . $stage,
				'changed'     => $changed,
				'ids'         => implode( ',', array_map( 'absint', (array) $ids ) ),
			),
			$redirect
		);
	}

	/**
	 * Queue the auto-move when an order becomes Processing.
	 *
	 * The move runs in an Action Scheduler async action, after the payment request has
	 * finished, so gateways that save the order again cannot overwrite the new status.
	 *
	 * @param int      $order_id Order ID.
	 * @param string   $from     Old status.
	 * @param string   $to       New status.
	 * @param WC_Order $order    Order.
	 */
	public function auto_move( $order_id, $from, $to, $order = null ) {
		if ( 'processing' !== $to || ! Shilpi_OS_Settings::enabled( 'auto_move' ) ) {
			return;
		}
		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! self::should_auto_move( $order ) ) {
			return;
		}
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::AUTO_MOVE_HOOK, array( 'order_id' => (int) $order_id ), 'shilpi-order-stages', true );
		} else {
			$this->run_auto_move( $order_id );
		}
	}

	/**
	 * Whether an order is a new Processing order that has not been auto-moved yet.
	 *
	 * @param WC_Order|false $order Order.
	 * @return bool
	 */
	public static function should_auto_move( $order ) {
		return $order instanceof WC_Order
			&& 'shop_order' === $order->get_type()
			&& 'processing' === $order->get_status()
			&& ! $order->get_meta( '_shilpi_os_auto_moved' );
	}

	/**
	 * Async action: move the order to the first stage if it is still waiting.
	 *
	 * @param int $order_id Order ID.
	 */
	public function run_auto_move( $order_id ) {
		if ( ! Shilpi_OS_Settings::enabled( 'auto_move' ) ) {
			return;
		}
		// Fresh copy from the database, never a cached object from the payment request.
		$order = wc_get_order( absint( $order_id ) );
		if ( ! self::should_auto_move( $order ) ) {
			return;
		}
		$keys = array_keys( Shilpi_OS_Stages::get_stages() );
		$order->update_meta_data( '_shilpi_os_auto_moved', time() );
		$order->update_status( $keys[0], __( 'Automatically moved to the first stage.', 'shilpi-order-stages' ) );
	}
}
